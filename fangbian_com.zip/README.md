To run the webapp, run the following commands in the root directory.

```sh
npm install

bower install

grunt serve
```