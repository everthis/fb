$(".login_header span").on('click', function(event) {
	event.preventDefault();
	/* Act on the event */
	$(".login_header span").removeClass('active');
	$(this).addClass('active');
	if ($(this).hasClass('pwd')) {
		$(".login_header").removeClass('reverse');
		$(".val_code_login").addClass('hide');
		$(".pwd_login").removeClass('hide');
	} else{
		$(".login_header").addClass('reverse');
		$(".val_code_login").removeClass('hide');
		$(".pwd_login").addClass('hide');
	};
});