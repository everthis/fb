$(".order_menu .menu").on('mouseover', function(event) {
	event.preventDefault();
	/* Act on the event */
	$(".order_menu .submenu").removeClass('hide');
	$(this).addClass('white_bg');
});
$(".order_menu .menu").on('mouseleave', function(event) {
	event.preventDefault();
	/* Act on the event */
	$(".order_menu .submenu").addClass('hide');
	$(this).removeClass('white_bg');
});

$("body").on('click', '.query_menu  .menu_item', function (event) {
    event.preventDefault();
    $(".query_menu  .menu_item").removeClass('active');
    $(this).addClass('active');
    var _category = $(this).attr('class').split(' ')[1];
    var $ori_dest = $(".query_form > .ori_dest");
    $ori_dest.removeClass('on').addClass('hide');
    for (var i = $ori_dest.length - 1; i >= 0; i--) {
    	if ($ori_dest.eq(i).hasClass(_category)) {
    		$ori_dest.eq(i).removeClass('hide').addClass('on');
    	};
    };

});


$("#train_from").css('color', '#999').val("请输入出发站");
$("#train_to").css('color', '#999').val("请输入到达站");

function startTime() {

    m = checkTime("#train_from", "请输入出发站", "");
    s = checkTime("#train_to", "请输入到达站", "");

    a = checkTime("#to_city", "请输入到达城市", "");
    b = checkTime("#from_city", "请输入出发城市", "");

    var t = setTimeout(function () { startTime() }, 10);
}

function checkTime(ele, text_one, text_two) {

    var $ele = $(ele);
    if ($ele.val() == text_one || $ele.val() == text_two) {
        $ele.css({
            'color': '#999',
            'font-size': '14px'
        });
    } else {
        $ele.css({
            'color': '#000',
            'font-size': '14px'
        });
    };
}
startTime();


$('.add_address').click(function(event) {
    $(".popup_address").removeClass('hide');
});

$('input[value="取消"]').click(function(event) {
    $(".popup_address").addClass('hide');
});

$('.passenger_list > .add_passenger_btn').click(function(event) {
    $(".popup_passenger").removeClass('hide');
});

$('input[value="取消"]').click(function(event) {
    $(".popup_passenger").addClass('hide');
});

        $("#btnsubmit").click(function(event) {
          var $ori_dest = $('#Form1 > .on');
          if ($ori_dest.hasClass('train')) {
            window.location.href ="train_query.html";
          } else if($ori_dest.hasClass('coach')) {
            window.location.href ="coach_query.html";

          };
        });

        $(".login_header span").on('click', function(event) {
            event.preventDefault();
            /* Act on the event */
            $(".login_header span").removeClass('active');
            $(this).addClass('active');
            if ($(this).hasClass('pwd')) {
                $(".login_header").removeClass('reverse');
                $(".val_code_login").addClass('hide');
                $(".pwd_login").removeClass('hide');
            } else{
                $(".login_header").addClass('reverse');
                $(".val_code_login").removeClass('hide');
                $(".pwd_login").addClass('hide');
            };
        });

        $('.pop_btn').click(function(event) {
            $(".shadow").removeClass('hide').css('z-index', '999'); ;
            $('div[class^="popup_"]').removeClass('hide').css('z-index', '9999'); ;
        });
                $('.close').click(function(event) {
                    $(this).parent().parent('div[class^="popup_"]').prev('.shadow').addClass('hide');
            // $(".shadow").addClass('hide');
            $(this).parent().parent('div[class^="popup_"]').addClass('hide');
        });