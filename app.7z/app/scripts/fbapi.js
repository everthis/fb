'use strict';
var FBAPI = {};
/**
 * [general_input description]
 * @param  {[type]}   service_id  [description]
 * @param  {[type]}   data        [description]
 * @param  {[type]}   api_method  [description]
 * @param  {[type]}   ajax_method [description]
 * @param  {Function} callback    [description]
 * @return {[type]}               [description]
 */
FBAPI.general_input = function(service_id, data, api_method, ajax_method, callback) {
    this.ci = "fbp0101abcd00001",
    this.ver = "1.0.0",
    this.ts = Date.now(),
    this.da = JSON.stringify(data),
    this.md5_private_key = md5("4C6EA522-9057"),
    this.si = service_id,
    this.md5_sign = md5(this.ci + this.si + this.ts + this.da + this.md5_private_key),

    this.api_method = api_method,
    this.ajax_method = ajax_method,
    this.ajax_data = {
        "client_id": this.ci,
        "service_id": this.si,
        "timestamp": this.ts,
        "version": this.ver,
        "sign": this.md5_sign,
        "data": this.da
    };
    this.Ajax(callback);
};
FBAPI.Ajax = function(callback) {
    $.ajax({
        url: "http://192.168.1.85/FangBianCRMInterface/m.ashx?action=" + this.api_method,
        method: this.ajax_method,
        dataType: "json",
        data: this.ajax_data,
        success: callback,
        error: function (ajaxContext) {
            console.log(ajaxContext.responseText)
        }
    });
};
FBAPI.get_brief_code = function() {
    this.general_input("U0100", "", "Query", "GET", this.get_brief_code_complete);
};
FBAPI.get_brief_code_complete = function(data) {
    for(var per_item of data.data) {
        var per_arr_item = [];
        per_arr_item.push(per_item["station_name"]);
        per_arr_item.push(per_item["brief_code"]);
        per_arr_item.push(per_item["full_spell"]);
        per_arr_item.push(per_item["first_letter"]);
        _ListData_.push(per_arr_item);
    }
};
FBAPI.query_train_tickets = function(date, origin, destination, passenger_type) {
    var query_train_data = {
        "train_date": date,
        "from_station": origin,
        "to_station": destination,
        "purpose_codes": passenger_type
    };
    this.general_input("U0109", query_train_data, "Query", "POST", this.query_train_tickets_complete);
};
FBAPI.query_train_tickets_complete = function(data) {
};
FBAPI.query_train_hots = function() {
    var query_train_data = {
        "search_type": 0
    };
    this.general_input("U0118", query_train_data, "Query", "POST", this.query_train_hots_complete);
};
FBAPI.query_train_hots_complete = function(data) {
    var hots = data.data;

    for(var per_hot of hots) {
        _index_train_hots.push(per_hot.stock_area_name);
    }
};

FBAPI.get_brief_code();
// FBAPI.query_train_tickets("2015-04-11", "SHH", "VAP", "ADULT");
FBAPI.query_train_hots();

